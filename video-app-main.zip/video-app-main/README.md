# video-app
1. I built a **Video call** app using html, css , javascript and used AGORA SDK for the ice servers used in the **Web RTC Connection**.
1. Web rtc is a project providing web browsers with real time communication via APIs. 
1. Using **WEB RTC** , you can do video or voice call through the browser itself.
1. In this app, you can video call anyone , through the website if you set up the OFFER and ANSWER for the ice servers to connect.
1. It has features to create, join and leave lobbies and hence, people can join different lobbies.
1. You can also turn your video and audio ON/OFF using the javascript button that i have built within the application.
